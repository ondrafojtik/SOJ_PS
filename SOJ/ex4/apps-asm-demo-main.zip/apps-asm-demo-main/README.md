## Examples of Assembly programming for APPS

These examples are part of study material for the basic assembly programming in the APPS subject.

To build examples use command `make` in all directories. 

## How-to

1. Downlod source codes.
2. Create copy of empty-project-* or try selected example. 
3. Edit source codes and build them by command `make`. Run from command line `./c_main`.
4. Also it is possible to import into Eclipse-C++. Import your code as C/C++ > Existing Code as Makefile project, e.g. see
    [video](https://www.youtube.com/watch?v=E36QpJdEghg&t=2m40s), time 2:40. And many more turorials
